=======================================================================
 TED-2026-08-2206-R  --  revised manuscript package
=======================================================================

BUILD
  pdflatex main
  bibtex   main
  pdflatex main
  pdflatex main

CLEAN vs MARKED COPY
  main.tex, line 20-21.  Swap which \rev line is commented:
      \newcommand{\rev}[1]{{\color{blue}#1}}   % MARKED  (default)
      %\newcommand{\rev}[1]{#1}                % CLEAN
  IEEE requires both files.

FILES
  main.tex                    document skeleton, class options, \rev switch
  macros.tex                  shared symbol definitions
  references.bib              35 entries
  sections/00_frontmatter.tex title, authors, abstract, index terms
  sections/01_introduction.tex
  sections/02_experiment.tex  device, provenance, methods, equations
  sections/03_results.tex
  sections/04_discussion.tex  mechanism, consistency, limitations
  sections/05_conclusion.tex
  sections/06_figures.tex     9 figure environments with captions
  sections/07_tables.tex      4 tables including the benchmark
  figures/FIG1..FIG9 .pdf

BEFORE SUBMISSION
  1. sections/07_tables.tex  -- every row marked  %% VERIFY  in the
     benchmark table needs its primary citation filled in. Four entries
     were traced through a thesis; cite the original papers.
  2. Identify which device gave the PUND and the transfer data
     (sections/02_experiment.tex, subsection "Devices and Data
     Provenance" currently says "a single device of the die").
  3. Verify all 35 bibliography entries against publisher records.
  4. Confirm author emails and the funding statement.

NOTE ON THE BIBLIOGRAPHY
  Three entries in the previous .bib had titles crossed with other
  entries and have been rebuilt:
     Yurchuk_trapping  (was Ref_DD_1, carried the MFM_ENDURANCE title)
     OV_model          (was ref_1_OV)
     OV_cycling        (was Ref_2OV)
  Citation keys in the text use the new names.
